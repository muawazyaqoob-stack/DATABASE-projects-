<?php
include 'db_connect.php';

// SQL query to create messages table
$sql = "CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<div style='text-align:center; margin-top:50px; font-family:sans-serif;'>";
    echo "<h1 style='color:#1dbf73;'>✅ SUCCESS!</h1>";
    echo "<h3>'messages' table has been created successfully.</h3>";
    echo "<p>Ab aapka navbar aur chat system kaam karega.</p>";
    echo "<a href='index.php' style='padding:10px 20px; background:#333; color:#fff; text-decoration:none; border-radius:5px;'>Go to Home</a>";
    echo "</div>";
} else {
    echo "Error creating table: " . $conn->error;
}
?>