<?php include 'navbar.php'; ?>

<style>
    body {
        background-color: #f1f2f5; /* Light grey background */
    }
    .auth-card {
        border: none;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        overflow: hidden;
    }
    .auth-header {
        background-color: white;
        padding: 30px 30px 10px 30px;
    }
    .form-control-lg {
        font-size: 15px;
        padding: 12px 20px;
        border-radius: 8px;
        border: 1px solid #e0e0e0;
        background-color: #f8f9fa;
    }
    .form-control-lg:focus {
        border-color: #1dbf73;
        box-shadow: 0 0 0 4px rgba(29, 191, 115, 0.1);
        background-color: white;
    }
    .btn-fiverr {
        background-color: #1dbf73;
        border: none;
        padding: 12px;
        font-weight: 700;
        font-size: 16px;
        border-radius: 8px;
        transition: all 0.3s;
    }
    .btn-fiverr:hover {
        background-color: #19a463;
        transform: translateY(-2px);
    }
</style>

<div class="container d-flex align-items-center justify-content-center" style="min-height: 80vh;">
    <div class="col-md-5 col-lg-4">
        <div class="card auth-card">
            <div class="card-body p-4 p-md-5">
                
                <div class="text-center mb-4">
                    <h3 class="fw-bold text-dark">Welcome Back</h3>
                    <p class="text-muted small">Login to manage your freelance business</p>
                </div>

                <form action="login_logic.php" method="POST">
                    <div class="form-floating mb-3">
                        <input type="email" name="email" class="form-control form-control-lg" id="emailInput" placeholder="name@example.com" required>
                        <label for="emailInput" class="text-muted">Email Address</label>
                    </div>

                    <div class="form-floating mb-4">
                        <input type="password" name="password" class="form-control form-control-lg" id="passInput" placeholder="Password" required>
                        <label for="passInput" class="text-muted">Password</label>
                    </div>

                    <button type="submit" class="btn btn-fiverr btn-primary w-100 text-white mb-3">Continue</button>
                    
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="rememberMe">
                            <label class="form-check-label small text-muted" for="rememberMe">Remember me</label>
                        </div>
                        <a href="#" class="text-decoration-none small text-success fw-bold">Forgot Password?</a>
                    </div>
                </form>
            </div>
            
            <div class="card-footer bg-white text-center py-3 border-top">
                <small class="text-muted">Not a member yet? <a href="register.php" class="text-success fw-bold text-decoration-none">Join now</a></small>
            </div>
        </div>
    </div>
</div>

<?php // Footer include karne ki zaroorat nahi yahan taake clean look rahe ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>