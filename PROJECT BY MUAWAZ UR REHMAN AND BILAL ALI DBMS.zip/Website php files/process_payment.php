<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $client_id = $_SESSION['user_id'];
    $service_id = mysqli_real_escape_string($conn, $_POST['service_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['method']);

    // 1. Seller ID fetch karein
    $gig_res = $conn->query("SELECT user_id FROM services WHERE service_id = '$service_id'");
    $seller_id = $gig_res->fetch_assoc()['user_id'];

    // 2. Pehle 'orders' table mein entry karein taake order_id mil jaye
    $order_sql = "INSERT INTO orders (client_id, seller_id, service_id, total_price, status) 
                  VALUES ('$client_id', '$seller_id', '$service_id', '$amount', 'Pending')";
    
    if ($conn->query($order_sql)) {
        $order_id = $conn->insert_id; // Nayi bani hui Order ID lena

        // 3. Ab 'payments' table mein entry karein (As per your structure)
        // Columns: order_id, amount, payment_method, STATUS
        $pay_sql = "INSERT INTO payments (order_id, amount, payment_method, STATUS) 
                    VALUES ('$order_id', '$amount', '$payment_method', 'Completed')";

        if ($conn->query($pay_sql)) {
            header("Location: payment_success.php?order_id=$order_id");
            exit();
        } else {
            echo "Payment Error: " . $conn->error;
        }
    } else {
        echo "Order Error: " . $conn->error;
    }
}
?>