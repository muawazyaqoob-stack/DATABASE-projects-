<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// 1. Column detection logic (freelancer_id vs user_id)
$check_gigs = $conn->query("SHOW COLUMNS FROM services LIKE 'freelancer_id'");
$gig_col = ($check_gigs->num_rows > 0) ? 'freelancer_id' : 'user_id';

// 2. Stats fetch for Glass Box
$total_gigs = $conn->query("SELECT COUNT(*) as count FROM services WHERE $gig_col = '$user_id'")->fetch_assoc()['count'];

include 'navbar.php';
?>

<style>
    /* Hero Section matching Order Page height */
    .gigs-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white;
        padding: 35px 0;
        min-height: 150px;
        display: flex;
        align-items: center;
        position: relative;
        overflow: hidden;
    }

    /* Glass Effect Box matching image_81f447.png */
    .glass-stats-card {
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: 15px 25px;
        display: inline-block;
        min-width: 220px;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.1);
    }

    .hero-title { font-weight: 700; font-size: 2.3rem; letter-spacing: -0.5px; }
    .stat-number { font-size: 2.5rem; font-weight: 700; line-height: 1; color: #ffffff; }
    .stat-label { font-size: 10px; text-transform: uppercase; font-weight: 800; letter-spacing: 1px; opacity: 0.9; }

    /* Custom Card for Gigs */
    .custom-table-card {
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        border-radius: 15px;
        overflow: hidden;
    }

    .gig-img-thumb {
        width: 70px;
        height: 45px;
        object-fit: cover;
        border-radius: 8px;
        border: 1px solid #eee;
    }
</style>

<div class="gigs-hero mb-5">
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-8 text-start">
                <h1 class="hero-title mb-1">Service Management</h1>
                <p class="mb-0 opacity-90">Review and manage your professional gigs.</p>
                <a href="add_service.php" class="btn btn-sm btn-light text-success fw-bold rounded-pill px-4 mt-3 shadow-sm">
                    <i class="bi bi-plus-lg me-1"></i> Create New Gig
                </a>
            </div>
            
            <div class="col-md-4 text-md-end mt-4 mt-md-0">
                <div class="glass-stats-card text-start">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-briefcase-fill fs-1 text-white"></i>
                        </div>
                        <div class="lh-1">
                            <div class="stat-number"><?php echo $total_gigs; ?></div>
                            <div class="stat-label mt-1 text-white">Total Active Gigs</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="card custom-table-card">
        <div class="card-header bg-white py-3 border-0">
            <h5 class="fw-bold mb-0 text-dark">Your Gigs Listing</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr class="small text-muted text-uppercase">
                        <th class="ps-4">Preview</th>
                        <th>Gig Title</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $res = $conn->query("SELECT * FROM services WHERE $gig_col = '$user_id' ORDER BY service_id DESC");
                    if ($res->num_rows > 0) {
                        while ($row = $res->fetch_assoc()) {
                            $img_path = !empty($row['image']) ? "uploads/".$row['image'] : "uploads/default.png";
                            ?>
                            <tr>
                                <td class="ps-4">
                                    <img src="<?php echo $img_path; ?>" class="gig-img-thumb">
                                </td>
                                <td class="py-3">
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['title']); ?></div>
                                    <small class="text-muted">ID: #<?php echo $row['service_id']; ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border fw-normal px-3"><?php echo htmlspecialchars($row['category']); ?></span></td>
                                <td class="fw-bold text-success">$<?php echo number_format($row['price'], 2); ?></td>
                                <td class="text-end pe-4">
                                    <a href="edit_service.php?id=<?php echo $row['service_id']; ?>" class="btn btn-sm btn-outline-success border-0 me-2"><i class="bi bi-pencil-square"></i></a>
                                    <a href="delete_service.php?id=<?php echo $row['service_id']; ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Delete this gig?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                        <?php } 
                    } else { ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <p class="text-muted mb-0">No Gigs found. Start by creating one!</p>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>