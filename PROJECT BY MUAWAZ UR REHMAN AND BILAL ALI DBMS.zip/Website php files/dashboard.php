<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// User Data Fetch
$user = $conn->query("SELECT * FROM users WHERE user_id = '$user_id'")->fetch_assoc();

// Column Auto-Detect Logic
$check_gigs = $conn->query("SHOW COLUMNS FROM services LIKE 'freelancer_id'");
$gig_col = ($check_gigs->num_rows > 0) ? 'freelancer_id' : 'user_id';

$check_orders = $conn->query("SHOW COLUMNS FROM orders LIKE 'freelancer_id'");
$order_col = ($check_orders->num_rows > 0) ? 'freelancer_id' : 'seller_id';

// Stats Fetch for Hero Section
$total_gigs = $conn->query("SELECT COUNT(*) as count FROM services WHERE $gig_col = '$user_id'")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE client_id = '$user_id' OR $order_col = '$user_id'")->fetch_assoc()['count'];

include 'navbar.php';
?>

<div class="Dashboard-hero py-5" style="background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%); color: white; min-height: 160px; display: flex; align-items: center; position: relative; overflow: hidden;">
    <div style="position: absolute; right: -30px; top: -30px; width: 220px; height: 220px; background: rgba(255, 255, 255, 0.05); border-radius: 50%;"></div>
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-7 text-start">
                <h1 class="fw-bold display-5 mb-1">Profile</h1>
                <p class="lead opacity-90 mb-0">Welcome back, <?php echo explode(' ', $user['full_name'])[0]; ?>! Manage your business here.</p>
            </div>
            <div class="col-md-5 text-md-end mt-4 mt-md-0">
                <div class="d-flex flex-wrap justify-content-md-end gap-3">
                    <div class="glass-box p-3 text-start" style="background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 15px; min-width: 160px;">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-grid-fill fs-2 me-3 text-white"></i>
                            <div>
                                <h3 class="fw-bold mb-0 text-white"><?php echo $total_gigs; ?></h3>
                                <small class="text-uppercase fw-bold opacity-75" style="font-size: 9px; letter-spacing: 1px;">My Gigs</small>
                            </div>
                        </div>
                    </div>
                    <div class="glass-box p-3 text-start" style="background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 15px; min-width: 160px;">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-bag-check-fill fs-2 me-3 text-white"></i>
                            <div>
                                <h3 class="fw-bold mb-0 text-white"><?php echo $total_orders; ?></h3>
                                <small class="text-uppercase fw-bold opacity-75" style="font-size: 9px; letter-spacing: 1px;">Total Orders</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 text-center p-4">
                <img src="uploads/<?php echo !empty($user['image']) ? $user['image'] : 'default.png'; ?>?v=<?php echo time(); ?>" 
                     class="rounded-circle mx-auto border border-3 border-success p-1 mb-3" 
                     style="width: 130px; height: 130px; object-fit: cover;">
                <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                <p class="text-muted small mb-4">Member Since: <?php echo date('F Y', strtotime($user['created_at'] ?? 'now')); ?></p>
                
                <div class="d-grid gap-2 mb-4">
                    <a href="edit_profile.php" class="btn btn-success rounded-pill fw-bold py-2">
                        <i class="bi bi-pencil-square me-2"></i> Edit Profile Settings
                    </a>
                    <a href="logout.php" class="btn btn-outline-danger rounded-pill fw-bold py-2">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </div>

                <div class="text-start">
                    <h6 class="fw-bold border-bottom pb-2">Description</h6>
                    <p class="text-muted small"><?php echo !empty($user['description']) ? htmlspecialchars($user['description']) : 'No description added yet.'; ?></p>
                    
                    <h6 class="fw-bold border-bottom pb-2 mt-4">Skills</h6>
                    <div class="d-flex flex-wrap gap-2">
                        <?php 
                        if(!empty($user['skills'])) {
                            foreach(explode(',', $user['skills']) as $skill) echo '<span class="badge bg-light text-dark border rounded-pill">'.trim($skill).'</span>';
                        } else { echo '<small class="text-muted">No skills listed.</small>'; }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden">
                <div class="card-header bg-white fw-bold py-3 border-0 d-flex justify-content-between align-items-center">
                    <span>My Active Gigs</span>
                    <a href="my_gigs.php" class="btn btn-sm btn-link text-success p-0 text-decoration-none">View All</a>
                </div>
                <div class="list-group list-group-flush border-top">
                    <?php
                    $gigs = $conn->query("SELECT * FROM services WHERE $gig_col = '$user_id' LIMIT 3");
                    if($gigs->num_rows > 0) {
                        while($g = $gigs->fetch_assoc()) { ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center py-3">
                                <div><h6 class="mb-0 fw-bold small text-dark"><?php echo $g['title']; ?></h6><small class="text-success">From $<?php echo $g['price']; ?></small></div>
                                <span class="badge bg-success-subtle text-success rounded-pill">Active</span>
                            </div>
                    <?php } } else { echo "<div class='p-4 text-center text-muted small'>No gigs found.</div>"; } ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white fw-bold py-3 border-0">Recent Orders</div>
                <div class="table-responsive p-3">
                    <table class="table table-sm align-middle mb-0">
                        <thead class="small text-muted table-light"><tr><th>Service</th><th>Status</th><th>Price</th></tr></thead>
                        <tbody>
                            <?php
                            $orders_q = "SELECT o.*, s.title FROM orders o 
                                         JOIN services s ON o.service_id = s.service_id 
                                         WHERE o.client_id = '$user_id' OR o.$order_col = '$user_id' 
                                         ORDER BY o.order_id DESC LIMIT 3";
                            $orders = $conn->query($orders_q);
                            if($orders && $orders->num_rows > 0) {
                                while($o = $orders->fetch_assoc()) {
                                    $price = $o['total_price'] ?? $o['price'] ?? '0.00';
                                    echo "<tr class='small'>
                                            <td><b class='text-dark'>{$o['title']}</b></td>
                                            <td><span class='badge bg-info-subtle text-info rounded-pill px-3'>{$o['status']}</span></td>
                                            <td class='fw-bold text-success'>\${$price}</td>
                                          </tr>";
                                }
                            } else { echo "<tr><td colspan='3' class='text-center py-3 text-muted small'>No orders found.</td></tr>"; }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden">
                <div class="card-header bg-white fw-bold py-3 border-0">Latest Feedback</div>
                <div class="card-body">
                    <?php
                    $revs_q = "SELECT r.*, u.full_name, u.image as uimg FROM reviews r 
                               JOIN orders o ON r.order_id = o.order_id 
                               JOIN users u ON o.client_id = u.user_id 
                               WHERE o.$order_col = '$user_id' ORDER BY r.review_id DESC LIMIT 2";
                    $revs = $conn->query($revs_q);
                    if($revs && $revs->num_rows > 0) {
                        while($rv = $revs->fetch_assoc()) { ?>
                            <div class="mb-3 pb-3 border-bottom last-child-border-0">
                                <div class="d-flex align-items-center mb-2">
                                    <img src="uploads/<?php echo $rv['uimg'] ?: 'default.png'; ?>" class="rounded-circle me-2" style="width: 35px; height: 35px; object-fit:cover;">
                                    <div>
                                        <div class="fw-bold small"><?php echo htmlspecialchars($rv['full_name']); ?></div>
                                        <div class="text-warning small" style="font-size: 10px;">
                                            <?php for($i=1; $i<=5; $i++) echo ($i <= $rv['rating']) ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>'; ?>
                                        </div>
                                    </div>
                                </div>
                                <p class="text-muted mb-0 small fst-italic">"<?php echo htmlspecialchars($rv['review_text']); ?>"</p>
                            </div>
                    <?php } } else { echo "<p class='text-muted small text-center mb-0'>No reviews yet.</p>"; } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .last-child-border-0:last-child { border-bottom: 0 !important; }
</style>