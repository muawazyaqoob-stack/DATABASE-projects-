<?php
include 'db_connect.php';

// Users table mein description column add karne ki koshish
$sql = "ALTER TABLE users ADD description TEXT NULL";

if ($conn->query($sql)) {
    echo "<h1 style='color:green; text-align:center; margin-top:50px;'>✅ SUCCESS! Description Column Added.</h1>";
    echo "<p style='text-align:center;'>Ab aap apni profile update kar sakte hain.</p>";
} else {
    // Agar column pehle se hai to error dikhaye ga
    echo "<h1 style='color:orange; text-align:center;'>⚠️ Column already exists or error:</h1> " . $conn->error;
}
?>