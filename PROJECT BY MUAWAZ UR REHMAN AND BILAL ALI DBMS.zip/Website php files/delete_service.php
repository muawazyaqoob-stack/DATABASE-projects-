<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $service_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Security Check: Kya yeh gig waqayi is user ki hai?
    // "AND user_id = '$user_id'" lagana zaroori hai taake koi aur delete na kar sake
    $sql = "DELETE FROM services WHERE service_id = '$service_id' AND user_id = '$user_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Gig Deleted Successfully!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    header("Location: dashboard.php");
}
$conn->close();
?>