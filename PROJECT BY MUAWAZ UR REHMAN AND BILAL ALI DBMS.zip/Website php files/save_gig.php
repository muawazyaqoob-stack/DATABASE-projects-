<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

// Sirf tab agay barhna hai jab form submit ho
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $delivery_time = mysqli_real_escape_string($conn, $_POST['delivery_time']);

    // 1. Image Upload handling
    $image_name = "";
    if (isset($_FILES['gig_image']) && $_FILES['gig_image']['error'] == 0) {
        $image_name = time() . "_" . $_FILES['gig_image']['name'];
        if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }
        move_uploaded_file($_FILES['gig_image']['tmp_name'], "uploads/" . $image_name);
    }

    // 2. Column detection (freelancer_id vs user_id)
    $check_col = $conn->query("SHOW COLUMNS FROM services LIKE 'freelancer_id'");
    $col_name = ($check_col->num_rows > 0) ? 'freelancer_id' : 'user_id';

    // 3. Database mein insert karna
    $sql = "INSERT INTO services ($col_name, title, description, category, price, delivery_time, image) 
            VALUES ('$user_id', '$title', '$description', '$category', '$price', '$delivery_time', '$image_name')";

    if ($conn->query($sql)) {
        // Gig save hone ke baad My Gigs page par wapis bhejna [cite: 43]
        header("Location: my_gigs.php?status=success");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>