<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if(!isset($_SESSION['user_id'])) { exit("Unauthorized"); }

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);

    // --- 1. ACCEPT ORDER (Pending to Active) ---
    if(isset($_POST['accept_order'])) {
        $sql = "UPDATE orders SET status = 'active' WHERE order_id = '$order_id'";
        if($conn->query($sql)) {
            header("Location: order_details.php?id=$order_id&msg=active");
            exit();
        }
    }

    // --- 2. DELIVER WORK (Active to Delivered) ---
    if(isset($_POST['deliver_work'])) {
        $details = mysqli_real_escape_string($conn, $_POST['delivery_details']);
        
        // Status update logic
        $sql = "UPDATE orders SET status = 'delivered', delivery_details = '$details' WHERE order_id = '$order_id'";
        
        if($conn->query($sql)) {
            header("Location: order_details.php?id=$order_id&msg=delivered");
            exit();
        } else {
            die("Database Error: " . $conn->error);
        }
    }

    // --- 3. APPROVE ORDER (Delivered to Completed) ---
    if(isset($_POST['approve_order'])) {
        $sql = "UPDATE orders SET status = 'completed' WHERE order_id = '$order_id'";
        if($conn->query($sql)) {
            header("Location: order_details.php?id=$order_id&msg=completed");
            exit();
        }
    }
}
?>