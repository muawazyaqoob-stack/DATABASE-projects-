<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php';
include 'navbar.php';

$search_query = "";
$where_clause = ""; 

if (isset($_GET['q'])) {
    $q = mysqli_real_escape_string($conn, $_GET['q']);
    $where_clause = "WHERE services.title LIKE '%$q%' OR services.category LIKE '%$q%'";
    $search_query = htmlspecialchars($_GET['q']);
}

if (isset($_GET['category'])) {
    $cat = mysqli_real_escape_string($conn, $_GET['category']);
    $where_clause = "WHERE services.category = '$cat'";
    $search_query = htmlspecialchars($_GET['category']);
}
?>

<style>
    body { background-color: #f7f7f7; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    
    /* --- HERO SECTION --- */
    .hero-section {
        background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
        padding: 90px 0;
        text-align: center;
        color: white;
        border-bottom-left-radius: 40px;
        border-bottom-right-radius: 40px;
        margin-bottom: 50px;
        position: relative;
    }
    .hero-title { font-size: 3rem; font-weight: 700; margin-bottom: 10px; }
    .hero-description { font-size: 1.1rem; color: rgba(255,255,255,0.8); margin-bottom: 30px; max-width: 750px; margin-left: auto; margin-right: auto; }

    /* Search Bar */
    .search-box-modern {
        background: white; padding: 5px; border-radius: 50px;
        display: flex; margin: 0 auto; max-width: 650px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
    }
    .search-box-modern input { border: none; flex: 1; padding: 15px 25px; outline: none; border-radius: 50px; font-size: 1rem; }
    .search-box-modern button { background: #1dbf73; color: white; border: none; padding: 0 35px; border-radius: 50px; font-weight: 600; }

    /* --- KEYWORDS / TAGS SECTION --- */
    .hero-keywords { margin-top: 25px; display: flex; align-items: center; justify-content: center; gap: 10px; flex-wrap: wrap; }
    .hero-keywords span { font-weight: 600; color: #fff; font-size: 0.9rem; }
    .hero-keywords a { 
        color: #fff; text-decoration: none; border: 1px solid rgba(255,255,255,0.4); 
        padding: 4px 15px; border-radius: 20px; font-size: 0.85rem; transition: 0.3s;
    }
    .hero-keywords a:hover { background: #1dbf73; border-color: #1dbf73; }

    /* --- GIG CARDS --- */
    .gig-card {
        background: white; border-radius: 8px; overflow: hidden;
        border: 1px solid #e4e5e7; transition: 0.3s;
        text-decoration: none !important; display: block; height: 100%;
    }
    .gig-card:hover { transform: translateY(-5px); border-color: #1dbf73; box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
    .img-wrapper { height: 180px; width: 100%; position: relative; }
    .green-placeholder { background-color: #1dbf73; height: 100%; width: 100%; display: flex; align-items: center; justify-content: center; text-align: center; padding: 15px; color: white; }
    .seller-badge { position: absolute; bottom: -18px; right: 15px; width: 40px; height: 40px; border-radius: 50%; background: #1dbf73; border: 3px solid white; display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; z-index: 5; }

    /* --- BLACK FOOTER --- */
    .black-footer { background-color: #202020; color: #fff; padding: 70px 0 30px 0; margin-top: 80px; }
    .footer-title { font-weight: 700; margin-bottom: 25px; font-size: 1.1rem; }
    .footer-links { list-style: none; padding: 0; }
    .footer-links li { margin-bottom: 12px; }
    .footer-links a { color: #b5b6ba; text-decoration: none; font-size: 0.95rem; }
    .footer-links a:hover { color: #1dbf73; }
    .footer-bottom { border-top: 1px solid #404145; margin-top: 50px; padding-top: 30px; }
    .text-success { color: #1dbf73 !important; }
</style>

<div class="hero-section">
    <div class="container">
        <h1 class="hero-title">Find the perfect <span class="text-success">freelance</span> services</h1>
        <p class="hero-description">Millions of people use MiniFiverr to turn their ideas into reality.</p>
        
        <form action="index.php" method="GET" class="search-box-modern">
            <input type="text" name="q" placeholder='Try "Logo Design"...' value="<?php echo $search_query; ?>">
            <button type="submit">Search</button>
        </form>

        <div class="hero-keywords">
            <span>Popular:</span>
            <a href="index.php?category=Web Development">Website Design</a>
            <a href="index.php?q=Logo">Logo Design</a>
            <a href="index.php?q=WordPress">WordPress</a>
            <a href="index.php?q=AI">AI Services</a>
        </div>
    </div>
</div>

<div class="container mb-5">
    <h3 class="fw-bold mb-4"><?php echo $search_query ? 'Search Results' : 'Explore Top Services'; ?></h3>
    <div class="row g-4">
        <?php
        $sql = "SELECT services.*, users.full_name FROM services 
                JOIN users ON services.user_id = users.user_id $where_clause 
                ORDER BY services.service_id DESC";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $has_image = (!empty($row['image']) && file_exists("uploads/" . $row['image'])) ? true : false;
                $initial = strtoupper(substr($row['full_name'], 0, 1));
                ?>
                <div class="col-md-3 col-sm-6">
                    <a href="service_details.php?id=<?php echo $row['service_id']; ?>" class="gig-card">
                        <div class="img-wrapper">
                            <?php if ($has_image): ?>
                                <img src="uploads/<?php echo $row['image']; ?>" class="gig-img" style="width:100%; height:100%; object-fit:cover;">
                            <?php else: ?>
                                <div class="green-placeholder">
                                    <h6 class="fw-bold m-0" style="font-size: 0.9rem; line-height: 1.4;"><?php echo htmlspecialchars($row['title']); ?></h6>
                                </div>
                            <?php endif; ?>
                            <div class="seller-badge"><?php echo $initial; ?></div>
                        </div>
                        <div class="p-3">
                            <div class="text-muted small fw-bold text-uppercase" style="font-size: 10px;"><?php echo htmlspecialchars($row['category']); ?></div>
                            <h6 class="text-dark fw-bold my-2" style="height: 40px; overflow: hidden; line-height: 1.3;"><?php echo htmlspecialchars($row['title']); ?></h6>
                            <div class="d-flex justify-content-between align-items-center mt-3 border-top pt-2">
                                <span class="text-muted small fw-bold"><?php echo htmlspecialchars($row['full_name']); ?></span>
                                <span class="fw-bold text-dark">Starting at <span class="text-success">$<?php echo $row['price']; ?></span></span>
                            </div>
                        </div>
                    </a>
                </div>
        <?php } } ?>
    </div>
</div>

<footer class="black-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mb-4">
                <h4 class="fw-bold mb-3">mini<span class="text-success">fiverr</span></h4>
                <p style="color: #b5b6ba; font-size: 0.9rem;">Connect with world-class talent to get your projects done faster. Safe, secure, and ready to start.</p>
            </div>
            <div class="col-lg-3 mb-4">
                <h6 class="footer-title">Categories</h6>
                <ul class="footer-links">
                    <li><a href="#">Graphics & Design</a></li>
                    <li><a href="#">Digital Marketing</a></li>
                    <li><a href="#">Writing & Translation</a></li>
                </ul>
            </div>
            <div class="col-lg-3 mb-4">
                <h6 class="footer-title">Support</h6>
                <ul class="footer-links">
                    <li><a href="#">Help & Support</a></li>
                    <li><a href="#">Trust & Safety</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="col-lg-3 mb-4">
                <h6 class="footer-title">About</h6>
                <ul class="footer-links">
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Press & News</a></li>
                    <li><a href="#">Terms of Service</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom text-center">
            <p class="m-0 small" style="color: #b5b6ba;">&copy; 2026 Mini Fiverr. Developed by <span class="text-success">Muawaz Ur Rehman</span> & <span class="text-success">Bilal Ali</span></p>
        </div>
    </div>
</footer>