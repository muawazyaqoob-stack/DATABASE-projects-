<?php
include 'db_connect.php';

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    $description = mysqli_real_escape_string($conn, $_POST['description']); // Description uthaya

    // Check if email exists
    $check = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($check->num_rows > 0) {
        $msg = "<div class='alert alert-danger'>Email already registered!</div>";
    } else {
        // Password Hash
        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
        
        // INSERT QUERY UPDATED (Description added)
        $sql = "INSERT INTO users (full_name, email, password, role, description) VALUES ('$full_name', '$email', '$hashed_pass', '$role', '$description')";
        
        if ($conn->query($sql)) {
            echo "<script>alert('Account created! Please login.'); window.location.href='login.php';</script>";
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Join - Mini Fiverr</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="min-height: 100vh;">

    <div class="card shadow border-0 p-4" style="width: 400px; border-radius: 15px;">
        <h3 class="text-center fw-bold mb-4">Join Mini Fiverr</h3>
        <?php echo $msg; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="fw-bold small">Full Name</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label class="fw-bold small">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label class="fw-bold small">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="fw-bold small">About Me (Description)</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Tell us about your skills..."></textarea>
            </div>

            <div class="mb-3">
                <label class="fw-bold small">I want to:</label>
                <select name="role" class="form-select">
                    <option value="freelancer">Sell Services (Freelancer)</option>
                    <option value="client">Buy Services (Client)</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success w-100 fw-bold rounded-pill">Register</button>
            <div class="text-center mt-3 small">
                Already a member? <a href="login.php" class="text-success fw-bold">Login</a>
            </div>
        </form>
    </div>

</body>
</html>