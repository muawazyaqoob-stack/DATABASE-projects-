<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
if (!isset($_GET['service_id'])) { header("Location: index.php"); exit(); }

$service_id = mysqli_real_escape_string($conn, $_GET['service_id']);
$service = $conn->query("SELECT title, price FROM services WHERE service_id = '$service_id'")->fetch_assoc();

include 'navbar.php';
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card border-0 shadow-sm rounded-4 p-5">
                <div class="text-center mb-4">
                    <h2 class="fw-bold text-dark">Submit Requirements</h2>
                    <p class="text-muted">You are ordering: <span class="text-success fw-bold"><?php echo htmlspecialchars($service['title']); ?></span></p>
                </div>

                <form action="place_order_logic.php" method="POST">
                    <input type="hidden" name="service_id" value="<?php echo $service_id; ?>">
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark">What do you need the freelancer to do?</label>
                        <textarea name="requirements" class="form-control rounded-4 p-3 border-success border-opacity-25" rows="7" 
                                  placeholder="Please provide all details, instructions, or links here..." required></textarea>
                    </div>

                    <div class="bg-light p-3 rounded-4 mb-4 d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-muted small text-uppercase">Total Amount</span>
                        <span class="h4 fw-bold text-success m-0">$<?php echo number_format($service['price'], 2); ?></span>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-success fw-bold py-3 rounded-pill shadow-sm">
                            Confirm and Place Order
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>