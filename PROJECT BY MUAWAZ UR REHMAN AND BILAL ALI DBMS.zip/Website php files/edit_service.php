<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// Check if ID is provided
if (!isset($_GET['id'])) { header("Location: my_gigs.php"); exit(); }
$service_id = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch existing data
$res = $conn->query("SELECT * FROM services WHERE service_id = '$service_id'");
$gig = $res->fetch_assoc();

include 'navbar.php';
?>

<style>
    /* Green Hero Section Match */
    .edit-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white;
        padding: 35px 0;
        min-height: 150px;
        display: flex;
        align-items: center;
    }
    .form-card {
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        background: #fff;
    }
    .btn-update {
        background: #1dbf73;
        color: white;
        font-weight: 700;
        border-radius: 10px;
        padding: 12px;
        border: none;
    }
    .btn-update:hover { background: #19a463; color: white; }
    .glass-info {
        background: rgba(29, 191, 115, 0.1);
        border: 1px solid rgba(29, 191, 115, 0.2);
        border-radius: 15px;
        padding: 20px;
    }
</style>

<div class="edit-hero mb-5">
    <div class="container">
        <h2 class="fw-bold display-6 mb-1">Edit Your Service</h2>
        <p class="opacity-90 mb-0">Update your gig details to keep your service fresh and relevant.</p>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card form-card p-4">
                <form action="update_service_logic.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="service_id" value="<?php echo $gig['service_id']; ?>">
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small uppercase">Gig Title</label>
                        <input type="text" name="title" class="form-control form-control-lg fs-6" value="<?php echo htmlspecialchars($gig['title']); ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold text-muted small">Category</label>
                            <select name="category" class="form-select">
                                <option value="Web Development" <?php if($gig['category'] == 'Web Development') echo 'selected'; ?>>Web Development</option>
                                <option value="Graphic Design" <?php if($gig['category'] == 'Graphic Design') echo 'selected'; ?>>Graphic Design</option>
                                <option value="Digital Marketing" <?php if($gig['category'] == 'Digital Marketing') echo 'selected'; ?>>Digital Marketing</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold text-muted small">Price ($)</label>
                            <input type="number" name="price" class="form-control" value="<?php echo $gig['price']; ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small">Gig Description</label>
                        <textarea name="description" class="form-control" rows="6"><?php echo htmlspecialchars($gig['description']); ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small">Change Gig Image (Optional)</label>
                        <input type="file" name="gig_image" class="form-control">
                        <small class="text-muted">Current: <?php echo $gig['image']; ?></small>
                    </div>

                    <button type="submit" class="btn btn-update w-100 shadow-sm">Save Changes</button>
                    <a href="my_gigs.php" class="btn btn-link w-100 text-muted mt-2 text-decoration-none">Cancel & Go Back</a>
                </form>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="glass-info">
                <h6 class="fw-bold text-success"><i class="bi bi-info-circle-fill me-2"></i>Why Update?</h6>
                <p class="small text-muted mb-0">Updating your price and description can help you stay competitive in the marketplace. Make sure to use high-quality keywords!</p>
            </div>
        </div>
    </div>
</div>