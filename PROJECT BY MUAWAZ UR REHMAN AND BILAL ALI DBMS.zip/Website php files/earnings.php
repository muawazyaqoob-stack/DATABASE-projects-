<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// 1. Column Auto-Detect Logic
$check_orders = $conn->query("SHOW COLUMNS FROM orders LIKE 'freelancer_id'");
$order_col = ($check_orders->num_rows > 0) ? 'freelancer_id' : 'seller_id';

// 2. FIXED QUERY: Earning calculate karne ke liye orders aur payments dono ka status check karna
$earnings_query = "SELECT SUM(p.amount) as total FROM payments p 
                   JOIN orders o ON p.order_id = o.order_id 
                   WHERE o.$order_col = '$user_id' 
                   AND (o.status = 'Completed' OR p.STATUS = 'Completed')";

$total_res = $conn->query($earnings_query);
$net_income = $total_res->fetch_assoc()['total'] ?? 0;

include 'navbar.php';
?>

<style>
    body { background-color: #f7f7f7; }
    .earnings-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white; padding: 45px 0; min-height: 160px;
        display: flex; align-items: center; position: relative; overflow: hidden;
    }
    .hero-decor {
        position: absolute; right: -50px; top: -50px; width: 250px; height: 250px;
        background: rgba(255, 255, 255, 0.1); border-radius: 50%; z-index: 1;
    }
    .glass-stat-card {
        background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 15px; padding: 20px; min-width: 240px; z-index: 2;
    }
    .table-card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
</style>

<div class="earnings-hero mb-5">
    <div class="hero-decor"></div>
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="fw-bold display-5 mb-1">Earnings</h1>
                <p class="mb-0 opacity-90">Manage your finances, view transactions, and track your success.</p>
            </div>
            <div class="col-md-5 text-md-end mt-4 mt-md-0">
                <div class="glass-stat-card text-start d-inline-block">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-wallet2 fs-1 me-3 text-white"></i>
                        <div>
                            <h2 class="fw-bold mb-0 text-white">$<?php echo number_format($net_income, 2); ?></h2>
                            <small class="text-uppercase fw-bold opacity-75" style="font-size: 10px; letter-spacing: 1px;">Net Income</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="card table-card overflow-hidden">
        <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0 text-dark">Recent Transactions</h5>
            <span class="badge bg-success-subtle text-success px-3 rounded-pill">Updated Live</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr class="small text-muted text-uppercase">
                        <th class="ps-4 py-3">Date</th>
                        <th>Order ID</th>
                        <th>Payment Method</th>
                        <th>Amount</th>
                        <th class="text-end pe-4">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Transaction History
                    $history_query = "SELECT p.*, o.status as order_status FROM payments p 
                                      JOIN orders o ON p.order_id = o.order_id 
                                      WHERE o.$order_col = '$user_id' 
                                      ORDER BY p.payment_id DESC";
                    $history = $conn->query($history_query);
                    
                    if ($history && $history->num_rows > 0) {
                        while($row = $history->fetch_assoc()) { 
                            $status = ($row['order_status'] == 'Completed') ? 'Completed' : $row['STATUS'];
                            ?>
                            <tr>
                                <td class="ps-4 small text-muted"><?php echo date('M d, Y', strtotime($row['payment_date'])); ?></td>
                                <td class="fw-bold text-dark">#<?php echo $row['order_id']; ?></td>
                                <td>
                                    <span class="small border px-2 py-1 rounded bg-white">
                                        <i class="bi bi-credit-card me-1"></i> <?php echo htmlspecialchars($row['payment_method']); ?>
                                    </span>
                                </td>
                                <td class="text-success fw-bold">+$<?php echo number_format($row['amount'], 2); ?></td>
                                <td class="text-end pe-4">
                                    <span class="badge bg-success-subtle text-success px-3 rounded-pill">
                                        <?php echo $status; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php }
                    } else {
                        echo "<tr><td colspan='5' class='text-center py-5'>
                                <i class='bi bi-cash-stack fs-1 text-muted opacity-25 d-block mb-2'></i>
                                <p class='text-muted mb-0'>No transactions found yet.</p>
                              </td></tr>";
                    } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>