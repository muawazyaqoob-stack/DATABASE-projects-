<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'])) {
    $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
    $rating = mysqli_real_escape_string($conn, $_POST['rating']);
    $review_text = mysqli_real_escape_string($conn, $_POST['review_text']);
    $client_id = $_SESSION['user_id']; // Logged in user who is giving the review

    // Corrected Query using 'client_id'
    $sql = "INSERT INTO reviews (order_id, client_id, rating, review_text, created_at) 
            VALUES ('$order_id', '$client_id', '$rating', '$review_text', NOW())";

    if ($conn->query($sql)) {
        // Redirect back with success message
        header("Location: order_details.php?id=" . $order_id . "&review=submitted");
        exit();
    } else {
        die("Database Error: " . $conn->error);
    }
}
?>