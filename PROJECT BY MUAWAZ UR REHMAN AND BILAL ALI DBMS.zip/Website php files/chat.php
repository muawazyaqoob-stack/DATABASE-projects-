<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// Jis bande se baat ho rahi hai uski ID
$receiver_id = isset($_GET['receiver_id']) ? mysqli_real_escape_string($conn, $_GET['receiver_id']) : 0;

if ($receiver_id == 0) { header("Location: messages.php"); exit(); }

// Receiver ka naam fetch karein
$receiver_info = $conn->query("SELECT full_name FROM users WHERE user_id = '$receiver_id'")->fetch_assoc();

include 'navbar.php';

// Messages ko 'read' mark karein
$conn->query("UPDATE messages SET is_read = 1 WHERE sender_id = '$receiver_id' AND receiver_id = '$user_id'");
?>

<div class="container mt-5 pt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-white border-0 py-3 d-flex align-items-center">
                    <a href="messages.php" class="text-dark me-3"><i class="bi bi-arrow-left fs-4"></i></a>
                    <h5 class="mb-0 fw-bold"><?php echo htmlspecialchars($receiver_info['full_name']); ?></h5>
                </div>
                
                <div class="card-body bg-light" id="chat-box" style="height: 400px; overflow-y: auto; padding: 20px;">
                    <?php
                    // Dono users ke darmiyan messages fetch karein
                    $msg_query = "SELECT * FROM messages 
                                 WHERE (sender_id = '$user_id' AND receiver_id = '$receiver_id') 
                                 OR (sender_id = '$receiver_id' AND receiver_id = '$user_id') 
                                 ORDER BY id ASC";
                    $msg_res = $conn->query($msg_query);

                    if ($msg_res->num_rows > 0) {
                        while($msg = $msg_res->fetch_assoc()) {
                            $is_me = ($msg['sender_id'] == $user_id);
                            ?>
                            <div class="d-flex <?php echo $is_me ? 'justify-content-end' : 'justify-content-start'; ?> mb-3">
                                <div class="p-3 rounded-4 <?php echo $is_me ? 'bg-success text-white' : 'bg-white border text-dark'; ?>" style="max-width: 75%;">
                                    <?php echo htmlspecialchars($msg['message']); ?>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="text-center text-muted">No messages yet. Say Hi!</p>';
                    }
                    ?>
                </div>

                <div class="card-footer bg-white border-0 py-3">
                    <form action="send_message.php" method="POST" class="d-flex gap-2">
                        <input type="hidden" name="receiver_id" value="<?php echo $receiver_id; ?>">
                        <input type="text" name="message" class="form-control rounded-pill px-4 shadow-none" placeholder="Type a message..." required>
                        <button type="submit" class="btn btn-success rounded-circle p-2 px-3"><i class="bi bi-send-fill"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Chat box ko hamesha scroll kar ke niche rakhega
    var chatBox = document.getElementById("chat-box");
    chatBox.scrollTop = chatBox.scrollHeight;
</script>