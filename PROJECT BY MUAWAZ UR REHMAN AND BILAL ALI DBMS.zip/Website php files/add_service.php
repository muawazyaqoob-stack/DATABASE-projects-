<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

include 'navbar.php';
?>

<style>
    body { background-color: #f4f7f6; }
    .create-gig-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white;
        padding: 40px 0;
        margin-bottom: 30px;
    }
    .form-card {
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    }
    .form-label { font-weight: 600; color: #444; font-size: 0.9rem; }
    .form-control, .form-select {
        border-radius: 10px;
        padding: 12px;
        border: 1px solid #e0e0e0;
    }
    .form-control:focus {
        border-color: #1dbf73;
        box-shadow: 0 0 0 0.25rem rgba(29, 191, 115, 0.1);
    }
    .preview-box {
        position: sticky;
        top: 100px;
        background: #fff;
        border-radius: 20px;
        border: 1px solid #eee;
        overflow: hidden;
    }
    .btn-publish {
        background: #1dbf73;
        color: white;
        font-weight: 700;
        padding: 12px;
        border-radius: 10px;
        transition: 0.3s;
    }
    .btn-publish:hover { background: #19a463; transform: translateY(-2px); }
</style>

<div class="create-gig-hero">
    <div class="container">
        <h2 class="fw-bold mb-1">Create A New Service</h2>
        <p class="opacity-75 mb-0">Set up your gig and start earning by helping clients worldwide.</p>
    </div>
</div>

<div class="container mb-5">
    <form action="save_gig.php" method="POST" enctype="multipart/form-data">
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card form-card p-4">
                    <h5 class="fw-bold mb-4 text-success border-bottom pb-2">Gig Overview</h5>
                    
                    <div class="mb-4">
                        <label class="form-label">GIG TITLE</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. I will design a professional logo for your brand" required>
                        <small class="text-muted">Direct and catchy titles work best.</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">CATEGORY</label>
                            <select name="category" class="form-select" required>
                                <option value="">Select Category</option>
                                <option value="Graphic Design">Graphic Design</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Digital Marketing">Digital Marketing</option>
                                <option value="Writing & Translation">Writing & Translation</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">PRICE ($)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">$</span>
                                <input type="number" name="price" class="form-control border-start-0" placeholder="5.00" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">DESCRIPTION</label>
                        <textarea name="description" class="form-control" rows="6" placeholder="Describe your service in detail..." required></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">DELIVERY TIME</label>
                            <select name="delivery_time" class="form-select">
                                <option value="1 Day">1 Day Delivery</option>
                                <option value="3 Days">3 Days Delivery</option>
                                <option value="7 Days">7 Days Delivery</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">GIG IMAGE</label>
                            <input type="file" name="gig_image" class="form-control" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-publish w-100 mt-3 shadow-sm">
                        <i class="bi bi-check-circle me-2"></i> Publish My Gig
                    </button>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="preview-box p-4 shadow-sm">
                    <h6 class="fw-bold mb-3"><i class="bi bi-lightbulb text-warning me-2"></i>Success Tips</h6>
                    <ul class="small text-muted ps-3 mb-4">
                        <li class="mb-2">Use high-quality images (1280x720px).</li>
                        <li class="mb-2">Keep your description clear and honest.</li>
                        <li>Competitive pricing attracts more orders.</li>
                    </ul>
                    
                    <div class="rounded-4 bg-light p-3 border text-center">
                        <i class="bi bi-image text-muted display-4"></i>
                        <p class="small text-muted mt-2 mb-0">Gig Image Preview will appear here after upload.</p>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>