<?php
$servername = "localhost";
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password (usually empty)
$dbname = "mini_fiverr"; // Jo database aapne phpMyAdmin mein banaya hai

// Connection create karna
$conn = new mysqli($servername, $username, $password, $dbname);

// Check karna agar koi error aye
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>