<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';
include 'navbar.php';

// Order ID fetch karna jo process_payment se aa rahi hai
$order_id = isset($_GET['order_id']) ? mysqli_real_escape_string($conn, $_GET['order_id']) : 'N/A';
?>

<div class="container text-center" style="margin-top: 80px; margin-bottom: 80px;">
    <div class="card border-0 shadow-lg p-5 mx-auto rounded-4" style="max-width: 550px; background: #fff;">
        <div class="mb-4">
            <div class="d-inline-flex align-items-center justify-content-center rounded-circle" style="background: #e6f7ed; width: 100px; height: 100px;">
                <i class="bi bi-check-lg text-success" style="font-size: 50px;"></i>
            </div>
        </div>
        
        <h2 class="fw-bold text-dark mb-2">Order Placed!</h2>
        <p class="text-muted px-3">Thank you for your purchase. Your payment has been processed and the seller has been notified.</p>
        
        <div class="p-3 rounded-4 mb-4 text-start border" style="background: #f8f9fa;">
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted small fw-bold">ORDER ID:</span>
                <span class="fw-bold text-dark">#<?php echo $order_id; ?></span>
            </div>
            <div class="d-flex justify-content-between">
                <span class="text-muted small fw-bold">STATUS:</span>
                <span class="badge bg-success-subtle text-success rounded-pill px-3">Paid & Confirmed</span>
            </div>
        </div>

        <div class="d-grid gap-2">
            <a href="my_orders.php" class="btn btn-success rounded-pill py-3 fw-bold shadow-sm">
                <i class="bi bi-bag-check me-2"></i> Manage My Orders
            </a>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill py-2 border-0">Back to Marketplace</a>
        </div>
    </div>
</div>