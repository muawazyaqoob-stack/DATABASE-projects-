<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'])) {
    $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $delivery_details = isset($_POST['delivery_details']) ? mysqli_real_escape_string($conn, $_POST['delivery_details']) : '';

    if ($status == 'Delivered') {
        // Update order with delivery message
        $sql = "UPDATE orders SET status = '$status', delivery_details = '$delivery_details' WHERE order_id = '$order_id'";
    } else if ($status == 'Completed') {
        // 1. Update Order Status to Completed
        $sql = "UPDATE orders SET status = '$status' WHERE order_id = '$order_id'";
        
        // 2. 🚀 CRITICAL: Update Payment Status to Completed
        $conn->query("UPDATE payments SET STATUS = 'Completed' WHERE order_id = '$order_id'");
    } else {
        $sql = "UPDATE orders SET status = '$status' WHERE order_id = '$order_id'";
    }
    
    if ($conn->query($sql)) {
        if ($status == 'Completed') {
            header("Location: submit_review.php?id=" . $order_id);
        } else {
            header("Location: order_details.php?id=" . $order_id);
        }
        exit();
    }
}
?>