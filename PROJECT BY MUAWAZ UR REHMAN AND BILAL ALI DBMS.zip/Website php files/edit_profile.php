<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// Profile Update Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $skills = mysqli_real_escape_string($conn, $_POST['skills']);

    // Database update query including new fields
    $update_query = "UPDATE users SET 
                     full_name = '$full_name', 
                     description = '$description', 
                     skills = '$skills' 
                     WHERE user_id = '$user_id'";
    
    if ($conn->query($update_query)) {
        // Image upload handling
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
            $new_filename = "user_" . $user_id . "_" . time() . ".jpg";
            if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], "uploads/" . $new_filename)) {
                $conn->query("UPDATE users SET image = '$new_filename' WHERE user_id = '$user_id'");
            }
        }
        header("Location: dashboard.php?status=success"); exit();
    }
}

// Fetch current user data to show in form
$res = $conn->query("SELECT * FROM users WHERE user_id = '$user_id'");
$user = $res->fetch_assoc();
include 'navbar.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow-sm border-0 rounded-4 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0">Update Profile Details</h4>
                    <a href="dashboard.php" class="btn-close"></a>
                </div>
                
                <form action="edit_profile.php" method="POST" enctype="multipart/form-data">
                    <div class="text-center mb-4">
                        <img src="uploads/<?php echo !empty($user['image']) ? $user['image'] : 'default.png'; ?>?v=<?php echo time(); ?>" 
                             class="rounded-circle border" style="width:100px; height:100px; object-fit:cover;">
                    </div>

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" class="form-control" rows="4" placeholder="Tell us about yourself..."><?php echo htmlspecialchars($user['description'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Skills (Comma separated)</label>
                            <input type="text" name="skills" class="form-control" value="<?php echo htmlspecialchars($user['skills'] ?? ''); ?>" placeholder="PHP, Web Design, MySQL">
                            <small class="text-muted">Example: PHP, Laravel, Bootstrap, Graphic Design</small>
                        </div>

                        <div class="col-md-12 mb-4">
                            <label class="form-label fw-bold">Change Profile Picture</label>
                            <input type="file" name="profile_image" class="form-control">
                        </div>
                    </div>

                    <button type="submit" name="update_profile" class="btn btn-success w-100 rounded-pill fw-bold py-2">Save All Changes</button>
                    <a href="dashboard.php" class="btn btn-link w-100 text-muted mt-2 text-decoration-none">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>