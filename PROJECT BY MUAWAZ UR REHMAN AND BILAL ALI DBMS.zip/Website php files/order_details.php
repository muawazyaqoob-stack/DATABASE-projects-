<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

$order_id = preg_replace('/[^0-9]/', '', $_GET['id'] ?? '');
$user_id = $_SESSION['user_id'];

// Query using freelancer_id and total_amount
$sql = "SELECT o.*, s.title, u.full_name as client_name FROM orders o 
        JOIN services s ON o.service_id = s.service_id 
        JOIN users u ON o.client_id = u.user_id
        WHERE o.order_id = '$order_id'";
$res = $conn->query($sql);
$order = $res->fetch_assoc();

if (!$order) { die("Order not found!"); }

$is_seller = ($order['freelancer_id'] == $user_id);
$status = strtolower($order['status']);

include 'navbar.php';
?>

<div class="container mt-5 mb-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                    <h3 class="fw-bold m-0 text-dark"><?php echo htmlspecialchars($order['title']); ?></h3>
                    <span class="badge bg-warning text-dark px-3 py-2 text-uppercase"><?php echo $order['status']; ?></span>
                </div>

                <h5 class="fw-bold text-success mb-3">Project Requirements</h5>
                <div class="p-4 bg-light rounded-4 border-start border-success border-5 mb-4">
                    <p class="mb-0 text-dark"><?php echo nl2br(htmlspecialchars($order['requirements'])); ?></p>
                </div>

                <div class="action-center mt-4 pt-4 border-top">
                    <?php if ($status == 'pending'): ?>
                        <?php if ($is_seller): ?>
                            <div class="text-center p-4 bg-success bg-opacity-10 rounded-4">
                                <h6 class="fw-bold text-success mb-3">Ready to deliver the project?</h6>
                                <form action="update_order.php" method="POST">
                                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                    <input type="hidden" name="status" value="Delivered">
                                    <button type="submit" class="btn btn-success fw-bold px-5 py-2 rounded-pill">Deliver Now</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info border-0 text-center rounded-4">Freelancer is working on your project.</div>
                        <?php endif; ?>

                    <?php elseif ($status == 'delivered'): ?>
                        <?php if (!$is_seller): ?>
                            <div class="text-center p-4 bg-primary bg-opacity-10 rounded-4">
                                <h6 class="fw-bold text-primary mb-3">Review the delivery and approve</h6>
                                <form action="update_order.php" method="POST">
                                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                    <input type="hidden" name="status" value="Completed">
                                    <button type="submit" class="btn btn-primary fw-bold px-5 py-2 rounded-pill">Approve & Complete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 p-4 text-center">
                <small class="text-muted fw-bold">TOTAL AMOUNT</small>
                <h2 class="text-success fw-bold mt-2">$<?php echo number_format($order['total_amount'], 2); ?></h2>
                <hr>
                <div class="small text-muted text-start">Order ID: <b>#ORD-<?php echo $order_id; ?></b></div>
            </div>
        </div>
    </div>
</div>