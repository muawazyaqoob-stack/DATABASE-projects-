<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $service_id = $_POST['service_id'];
    $user_id = $_SESSION['user_id'];
    
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = $_POST['price'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // --- IMAGE UPDATE LOGIC ---
    // Agar nayi image upload hui hai, toh SQL query mein image bhi update hogi.
    // Agar nahi hui, toh purani image hi rahegi.
    
    if (isset($_FILES['gig_image']) && $_FILES['gig_image']['error'] == 0) {
        $target_dir = "uploads/";
        $image_name = time() . "_" . basename($_FILES["gig_image"]["name"]);
        move_uploaded_file($_FILES["gig_image"]["tmp_name"], $target_dir . $image_name);
        
        // Update Query WITH Image
        $sql = "UPDATE services SET 
                title='$title', 
                category='$category', 
                price='$price', 
                description='$description', 
                image='$image_name' 
                WHERE service_id='$service_id' AND user_id='$user_id'";
    } else {
        // Update Query WITHOUT Image (Purani rahay)
        $sql = "UPDATE services SET 
                title='$title', 
                category='$category', 
                price='$price', 
                description='$description' 
                WHERE service_id='$service_id' AND user_id='$user_id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Gig Updated Successfully!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
$conn->close();
?>