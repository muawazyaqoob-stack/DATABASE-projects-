<?php
include 'db_connect.php';

// Column add karne ki query
$sql = "ALTER TABLE orders ADD COLUMN delivery_details TEXT NULL";

echo "<div style='font-family:sans-serif; text-align:center; margin-top:50px;'>";

if ($conn->query($sql) === TRUE) {
    echo "<h1 style='color:#1dbf73;'>✅ Column Added Successfully!</h1>";
    echo "<p>Ab aapka delivery wala error khatam ho jayega.</p>";
} else {
    // Agar column pehle se hai ya koi aur error hai
    echo "<h1 style='color:#ff4d4d;'>⚠️ Notice</h1>";
    echo "<p>Result: " . $conn->error . "</p>";
    echo "<p>Agar error 'Duplicate column name' hai, to iska matlab hai column pehle hi ban chuka hai.</p>";
}

echo "<br><a href='order_details.php' style='padding:10px 20px; background:#333; color:#fff; text-decoration:none; border-radius:5px;'>Back to Orders</a>";
echo "</div>";
?>