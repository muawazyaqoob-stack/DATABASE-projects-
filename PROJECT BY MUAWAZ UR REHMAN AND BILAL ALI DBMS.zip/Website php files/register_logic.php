<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    $skills = isset($_POST['skills']) ? mysqli_real_escape_string($conn, $_POST['skills']) : '';

    $check = "SELECT * FROM users WHERE email='$email'";
    if ($conn->query($check)->num_rows > 0) {
        echo "<script>alert('Email already exists!'); window.location.href='register.php';</script>";
        exit();
    }

    // IMAGE UPLOAD
    $image_name = "";
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $target_dir = "uploads/";
        $image_name = "user_" . time() . "_" . basename($_FILES["profile_image"]["name"]);
        move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_dir . $image_name);
    }
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (full_name, email, password, role, skills, image) VALUES ('$full_name', '$email', '$hashed_password', '$role', '$skills', '$image_name')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Account Created! Login Now.'); window.location.href='login.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
$conn->close();
?>