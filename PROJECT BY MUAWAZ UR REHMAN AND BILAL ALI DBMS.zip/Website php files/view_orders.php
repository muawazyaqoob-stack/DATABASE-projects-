<?php
// view_orders.php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    echo "Please <a href='login.php'>login</a>.";
    exit;
}
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role == 'client') {
    $stmt = $mysqli->prepare("SELECT o.*, s.title, u.full_name AS freelancer_name FROM orders o JOIN services s ON o.service_id = s.service_id JOIN users u ON o.freelancer_id = u.user_id WHERE o.client_id = ? ORDER BY o.created_at DESC");
    $stmt->bind_param('i', $user_id);
} else {
    // freelancer: show orders assigned to them
    $stmt = $mysqli->prepare("SELECT o.*, s.title, u.full_name AS client_name FROM orders o JOIN services s ON o.service_id = s.service_id JOIN users u ON o.client_id = u.user_id WHERE o.freelancer_id = ? ORDER BY o.created_at DESC");
    $stmt->bind_param('i', $user_id);
}
$stmt->execute();
$res = $stmt->get_result();
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>My Orders</title><link rel="stylesheet" href="style.css"></head><body>
<h2>My Orders</h2>
<?php
if ($res->num_rows == 0) {
    echo "<p>No orders found.</p>";
} else {
    while($o = $res->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<h3>" . htmlspecialchars($o['title']) . "</h3>";
        if ($role=='client') echo "<p>Freelancer: ".htmlspecialchars($o['freelancer_name'])."</p>";
        else echo "<p>Client: ".htmlspecialchars($o['client_name'])."</p>";
        echo "<p>Status: ".htmlspecialchars($o['status'])." • $".number_format($o['total_amount'],2)."</p>";
        echo "<p><a href='order_details.php?id=".$o['order_id']."'>Details</a></p>";
        echo "</div>";
    }
}
?>
</body></html>
