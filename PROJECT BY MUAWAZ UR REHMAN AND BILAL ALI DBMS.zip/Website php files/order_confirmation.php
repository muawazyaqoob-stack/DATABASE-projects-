<?php
session_start();
include 'db_connect.php';
include 'navbar.php';

// Agar login nahi hai to login page par bhej do
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please Login to Place an Order!'); window.location.href='login.php';</script>";
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$service_id = $_GET['id'];
$client_id = $_SESSION['user_id'];

// Service details lana
$sql = "SELECT * FROM services WHERE service_id = '$service_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Agar banda apni hi gig khareed raha ho to rok dein
if ($row['user_id'] == $client_id) {
    echo "<div class='container py-5 text-center'>
            <div class='alert alert-warning'>You cannot buy your own Gig!</div>
            <a href='index.php' class='btn btn-primary'>Go Back</a>
          </div>";
    include 'footer.php'; // Optional
    exit();
}

$fee = $row['price'] * 0.10; // 10% Service Fee
$total = $row['price'] + $fee;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-success text-white p-4 text-center">
                    <h3 class="fw-bold m-0">Order Summary</h3>
                </div>
                <div class="card-body p-5">
                    
                    <h5 class="fw-bold mb-3 text-dark"><?php echo htmlspecialchars($row['title']); ?></h5>
                    <span class="badge bg-light text-dark border mb-4"><?php echo htmlspecialchars($row['category']); ?></span>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-bold">$<?php echo $row['price']; ?></span>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <span class="text-muted">Service Fee (10%)</span>
                        <span class="fw-bold">$<?php echo number_format($fee, 2); ?></span>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between mb-4 fs-4 text-success">
                        <span class="fw-bold">Total</span>
                        <span class="fw-bold">$<?php echo number_format($total, 2); ?></span>
                    </div>

                    <form action="place_order_logic.php" method="POST">
                        <input type="hidden" name="service_id" value="<?php echo $row['service_id']; ?>">
                        <input type="hidden" name="freelancer_id" value="<?php echo $row['user_id']; ?>">
                        <input type="hidden" name="amount" value="<?php echo $total; ?>">
                        
                        <div class="mb-4 bg-light p-3 rounded border">
                            <label class="fw-bold small text-muted mb-2">PAYMENT METHOD</label>
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-credit-card-2-front fs-4 text-primary"></i>
                                <span class="fw-bold text-dark">Visa / MasterCard (Mock)</span>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success w-100 py-3 fw-bold btn-lg">
                            Confirm & Pay
                        </button>
                        <a href="service_details.php?id=<?php echo $service_id; ?>" class="btn btn-link text-muted w-100 mt-2 text-decoration-none">Cancel</a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>