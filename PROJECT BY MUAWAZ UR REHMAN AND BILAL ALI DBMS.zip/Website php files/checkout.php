<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

// Gig ID fetch karna jo khareedi ja rahi hai
$service_id = isset($_GET['service_id']) ? mysqli_real_escape_string($conn, $_GET['service_id']) : 0;
$res = $conn->query("SELECT s.*, u.full_name FROM services s JOIN users u ON s.user_id = u.user_id WHERE s.service_id = '$service_id'");
$gig = $res->fetch_assoc();

if (!$gig) { echo "Service not found!"; exit(); }

include 'navbar.php';
?>

<style>
    .payment-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white; padding: 40px 0; min-height: 150px;
        display: flex; align-items: center; position: relative; overflow: hidden;
    }
    .glass-payment-card {
        background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 15px;
        padding: 15px 25px; color: white;
    }
    .checkout-card { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
    .payment-option {
        border: 2px solid #eee; border-radius: 12px; padding: 15px;
        cursor: pointer; transition: 0.3s; margin-bottom: 15px;
    }
    .payment-option:hover { border-color: #1dbf73; background: #f0fff4; }
    .form-check-input:checked + .payment-content { color: #1dbf73; }
</style>

<div class="payment-hero mb-5">
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="fw-bold mb-1">Checkout</h1>
                <p class="mb-0 opacity-90">Securely complete your purchase and start your project.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <div class="glass-payment-card text-start d-inline-block">
                    <small class="text-uppercase fw-bold opacity-75">Order Total</small>
                    <h2 class="fw-bold mb-0 text-white">$<?php echo number_format($gig['price'], 2); ?></h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card checkout-card p-4">
                <h5 class="fw-bold mb-4">Select Payment Method</h5>
                <form action="process_payment.php" method="POST">
                    <input type="hidden" name="service_id" value="<?php echo $service_id; ?>">
                    <input type="hidden" name="amount" value="<?php echo $gig['price']; ?>">

                    <div class="payment-option d-flex align-items-center">
                        <input class="form-check-input me-3" type="radio" name="method" id="card" value="Credit Card" checked>
                        <label class="form-check-label w-100" for="card">
                            <div class="d-flex justify-content-between">
                                <span>Credit or Debit Card</span>
                                <i class="bi bi-credit-card-2-back fs-4 text-muted"></i>
                            </div>
                        </label>
                    </div>

                    <div class="payment-option d-flex align-items-center">
                        <input class="form-check-input me-3" type="radio" name="method" id="easypaisa" value="EasyPaisa">
                        <label class="form-check-label w-100" for="easypaisa">
                            <div class="d-flex justify-content-between">
                                <span>EasyPaisa / JazzCash</span>
                                <i class="bi bi-wallet2 fs-4 text-muted"></i>
                            </div>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-success w-100 py-3 mt-4 fw-bold rounded-pill">Confirm & Pay</button>
                </form>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card checkout-card p-4 bg-light">
                <h5 class="fw-bold mb-3">Order Summary</h5>
                <div class="d-flex mb-3">
                    <img src="uploads/<?php echo !empty($gig['image']) ? $gig['image'] : 'default.png'; ?>" class="rounded-3 me-3" style="width: 100px; height: 70px; object-fit: cover;">
                    <div>
                        <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($gig['title']); ?></h6>
                        <small class="text-muted">Seller: <?php echo htmlspecialchars($gig['full_name']); ?></small>
                    </div>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span>Service Price</span>
                    <span>$<?php echo number_format($gig['price'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Service Fee</span>
                    <span>$2.00</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between fw-bold fs-5">
                    <span>Total</span>
                    <span class="text-success">$<?php echo number_format($gig['price'] + 2, 2); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>