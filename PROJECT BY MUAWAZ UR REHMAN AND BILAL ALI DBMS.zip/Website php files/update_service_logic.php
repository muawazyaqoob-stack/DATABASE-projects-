<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['service_id'])) {
    $service_id = mysqli_real_escape_string($conn, $_POST['service_id']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // 1. Basic Update Query
    $sql = "UPDATE services SET 
            title = '$title', 
            category = '$category', 
            price = '$price', 
            description = '$description' 
            WHERE service_id = '$service_id'";

    if ($conn->query($sql)) {
        // 2. Agar nayi image upload hui hai to usay handle karein
        if (isset($_FILES['gig_image']) && $_FILES['gig_image']['error'] == 0) {
            $image_name = time() . "_" . $_FILES['gig_image']['name'];
            if (move_uploaded_file($_FILES['gig_image']['tmp_name'], "uploads/" . $image_name)) {
                $conn->query("UPDATE services SET image = '$image_name' WHERE service_id = '$service_id'");
            }
        }
        
        // Success ke baad wapis My Gigs page par
        header("Location: my_gigs.php?status=updated");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>