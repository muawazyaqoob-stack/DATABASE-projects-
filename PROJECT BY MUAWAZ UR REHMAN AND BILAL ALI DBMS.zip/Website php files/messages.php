<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

include 'navbar.php';

// Messages ko 'read' mark karna taake notification khatam ho jaye
$conn->query("UPDATE messages SET is_read = 1 WHERE receiver_id = '$user_id'");

// Stats fetch karna Glass Box ke liye
$total_chats_res = $conn->query("SELECT COUNT(DISTINCT CASE WHEN sender_id = '$user_id' THEN receiver_id ELSE sender_id END) AS total FROM messages WHERE sender_id = '$user_id' OR receiver_id = '$user_id'");
$total_chats = $total_chats_res->fetch_assoc()['total'];
?>

<style>
    /* Messages Hero Section Pattern */
    .messages-hero {
        background: linear-gradient(90deg, #1dbf73 0%, #19a463 100%);
        color: white;
        padding: 35px 0;
        min-height: 150px;
        display: flex;
        align-items: center;
        position: relative;
        overflow: hidden;
    }

    /* Decorative Background Circle */
    .hero-circle-decor {
        position: absolute;
        right: -40px;
        top: -40px;
        width: 200px;
        height: 200px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        z-index: 1;
    }

    /* Glassmorphism Stats Box */
    .glass-msg-stat {
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 15px;
        padding: 15px 25px;
        display: inline-block;
        min-width: 200px;
        z-index: 2;
    }

    .chat-list-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    .contact-item {
        transition: all 0.2s;
        border-bottom: 1px solid #f8f9fa !important;
    }

    .contact-item:hover {
        background-color: #f0fff4;
    }
</style>

<div class="messages-hero mb-5">
    <div class="hero-circle-decor"></div>
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-8 text-start">
                <h1 class="fw-bold display-5 mb-1">Messages</h1>
                <p class="mb-0 opacity-90">Stay connected and collaborate with your business partners.</p>
            </div>
            
            <div class="col-md-4 text-md-end mt-4 mt-md-0">
                <div class="glass-msg-stat text-start">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-chat-right-text-fill fs-2 text-white"></i>
                        </div>
                        <div>
                            <h3 class="fw-bold mb-0 text-white"><?php echo $total_chats; ?></h3>
                            <small class="text-uppercase fw-bold opacity-75" style="font-size: 10px; letter-spacing: 0.5px;">Total Chats</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card chat-list-card overflow-hidden">
                <div class="card-header bg-white fw-bold py-3 border-0">
                    <i class="bi bi-clock-history me-2"></i> Recent Chats
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    $chat_users_query = "SELECT DISTINCT 
                                            CASE 
                                                WHEN sender_id = '$user_id' THEN receiver_id 
                                                ELSE sender_id 
                                            END AS contact_id 
                                         FROM messages 
                                         WHERE sender_id = '$user_id' OR receiver_id = '$user_id'
                                         ORDER BY id DESC";
                    
                    $chat_users_res = $conn->query($chat_users_query);

                    if ($chat_users_res && $chat_users_res->num_rows > 0) {
                        while($chat_user = $chat_users_res->fetch_assoc()) {
                            $contact_id = $chat_user['contact_id'];
                            $user_info = $conn->query("SELECT full_name, image FROM users WHERE user_id = '$contact_id'")->fetch_assoc();
                            ?>
                            <a href="chat.php?receiver_id=<?php echo $contact_id; ?>" class="list-group-item list-group-item-action contact-item d-flex align-items-center py-3">
                                <?php if(!empty($user_info['image'])): ?>
                                    <img src="uploads/<?php echo $user_info['image']; ?>" class="rounded-circle me-3 border" style="width: 45px; height: 45px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-circle bg-light d-flex align-items-center justify-content-center me-3 border" style="width: 45px; height: 45px;">
                                        <i class="bi bi-person text-secondary fs-4"></i>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($user_info['full_name']); ?></div>
                                    <small class="text-muted" style="font-size: 11px;">View Conversation</small>
                                </div>
                            </a>
                            <?php
                        }
                    } else {
                        echo '<div class="p-5 text-center text-muted">No chats found.</div>';
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card chat-list-card d-flex align-items-center justify-content-center text-muted bg-white" style="height: 500px;">
                <div class="text-center">
                    <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="bi bi-chat-dots text-success fs-1"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Your Inbox</h5>
                    <p class="small px-5">Select a person from the left to start your professional conversation.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>