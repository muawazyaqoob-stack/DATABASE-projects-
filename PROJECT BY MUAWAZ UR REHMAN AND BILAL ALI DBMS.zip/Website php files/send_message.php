<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $sender_id = $_SESSION['user_id'];
    $receiver_id = mysqli_real_escape_string($conn, $_POST['receiver_id']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    if (!empty($message)) {
        // Message ko database mein insert karna
        // Note: is_read default 0 hota hai
        $sql = "INSERT INTO messages (sender_id, receiver_id, message, is_read) 
                VALUES ('$sender_id', '$receiver_id', '$message', 0)";
        
        if ($conn->query($sql)) {
            // Message send hone ke baad wapis usi chat par bhejen
            header("Location: chat.php?receiver_id=" . $receiver_id);
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        header("Location: chat.php?receiver_id=" . $receiver_id);
    }
} else {
    header("Location: messages.php");
}
exit();
?>