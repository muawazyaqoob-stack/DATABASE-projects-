<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { exit(); }

$my_id = $_SESSION['user_id'];
$action = isset($_POST['action']) ? $_POST['action'] : '';
$receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : 0;

if($action == 'send' && $receiver_id > 0) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    if(!empty($message)) {
        $conn->query("INSERT INTO messages (sender_id, receiver_id, message) VALUES ('$my_id', '$receiver_id', '$message')");
    }
}

if($action == 'fetch' && $receiver_id > 0) {
    $sql = "SELECT * FROM messages 
            WHERE (sender_id = '$my_id' AND receiver_id = '$receiver_id') 
            OR (sender_id = '$receiver_id' AND receiver_id = '$my_id') 
            ORDER BY created_at ASC";
    $result = $conn->query($sql);
    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $class = ($row['sender_id'] == $my_id) ? 'msg-me' : 'msg-other';
            $time = date('h:i A', strtotime($row['created_at']));
            
            echo "<div class='msg $class shadow-sm'>";
            echo htmlspecialchars($row['message']);
            echo "<span class='msg-time'>$time</span>";
            echo "</div>";
        }
    } else {
        echo "<div class='text-center text-muted mt-5 small'>No messages yet. Say Hi!</div>";
    }
}
?>