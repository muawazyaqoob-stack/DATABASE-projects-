<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// Column detection for orders table
$check_orders = $conn->query("SHOW COLUMNS FROM orders LIKE 'freelancer_id'");
$order_col = ($check_orders->num_rows > 0) ? 'freelancer_id' : 'seller_id';

// Stats for Hero Section
$total_orders_res = $conn->query("SELECT COUNT(*) as count FROM orders WHERE client_id = '$user_id' OR $order_col = '$user_id'");
$total_orders = $total_orders_res->fetch_assoc()['count'];

include 'navbar.php';
?>

<style>
    /* Professional Styling */
    .orders-hero { background: linear-gradient(135deg, #1dbf73 0%, #0d8a51 100%); color: white; position: relative; overflow: hidden; }
    .orders-hero::after { content: ""; position: absolute; top: -50%; right: -5%; width: 350px; height: 350px; background: rgba(255, 255, 255, 0.1); border-radius: 50%; z-index: 1; }
    .clickable-row { cursor: pointer; transition: 0.2s; }
    .clickable-row:hover { background-color: #f4fff9 !important; }
</style>

<div class="orders-hero py-5 mb-5">
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="fw-bold display-5 mb-2">Order Management</h1>
                <p class="lead opacity-75 mb-0">Track project milestones and view detailed order history.</p>
            </div>
            <div class="col-md-4 text-md-end mt-4 mt-md-0">
                <div class="bg-white bg-opacity-25 rounded-4 p-3 d-inline-block border border-white border-opacity-25 shadow-sm">
                    <div class="d-flex align-items-center text-start">
                        <div class="me-3"><i class="bi bi-bag-check-fill fs-1"></i></div>
                        <div>
                            <h3 class="fw-bold mb-0"><?php echo $total_orders; ?></h3>
                            <small class="text-uppercase fw-bold opacity-75" style="font-size: 10px;">Total Projects</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">Recent Order History</h5>
            <small class="text-muted">Click any row to view details</small>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light text-muted small text-uppercase">
                    <tr>
                        <th class="ps-4">Service Details</th>
                        <th>Order ID</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetching orders with fallbacks for price columns
                    $sql = "SELECT o.*, s.title, s.price as gig_price 
                            FROM orders o 
                            JOIN services s ON o.service_id = s.service_id 
                            WHERE o.client_id = '$user_id' OR o.$order_col = '$user_id' 
                            ORDER BY o.order_id DESC";
                    
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            
                            // 🚀 FIX: Undefined array key "total_price" solution
                            // Hum check kar rahe hain ke kaunsa column database mein mojood hai
                            $display_price = 0;
                            if (isset($row['total_price']) && $row['total_price'] > 0) {
                                $display_price = $row['total_price'];
                            } elseif (isset($row['price']) && $row['price'] > 0) {
                                $display_price = $row['price'];
                            } else {
                                $display_price = $row['gig_price']; // Fallback to gig price
                            }

                            // Status Badge Styling
                            $status = strtolower($row['status']);
                            $badge_class = 'bg-warning-subtle text-warning';
                            if ($status == 'completed') $badge_class = 'bg-success-subtle text-success';
                            if ($status == 'delivered') $badge_class = 'bg-info-subtle text-info';
                            ?>
                            
                            <tr class="clickable-row" onclick="window.location='order_details.php?id=<?php echo $row['order_id']; ?>';">
                                <td class="ps-4 py-3">
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['title']); ?></div>
                                    <small class="text-muted">Placed on: <?php echo date('d M, Y', strtotime($row['created_at'] ?? 'now')); ?></small>
                                </td>
                                <td><span class="text-muted small">#ORD-<?php echo $row['order_id']; ?></span></td>
                                <td><span class="fw-bold text-success">$<?php echo number_format($display_price, 2); ?></span></td>
                                <td>
                                    <span class="badge rounded-pill px-3 py-2 text-capitalize <?php echo $badge_class; ?>">
                                        <?php echo $row['status']; ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="order_details.php?id=<?php echo $row['order_id']; ?>" class="btn btn-sm btn-outline-success rounded-pill px-3">View</a>
                                </td>
                            </tr>
                            
                        <?php } 
                    } else { ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No orders found.</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>