<?php 
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'navbar.php'; 
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header bg-success text-white p-4">
                    <h3 class="mb-0 fw-bold">Post a Gig</h3>
                </div>
                <div class="card-body p-5">
                    <form action="add_service_logic.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label class="fw-bold">Gig Title</label>
                            <input type="text" name="title" class="form-control" placeholder="I will do..." required>
                        </div>
                        <div class="mb-4">
                            <label class="fw-bold">Gig Image</label>
                            <input type="file" name="gig_image" class="form-control" accept="image/*" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label class="fw-bold">Category</label>
                                <select name="category" class="form-select">
                                    <option>Graphics & Design</option>
                                    <option>Web Development</option>
                                    <option>Video & Animation</option>
                                    <option>Business</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label class="fw-bold">Delivery Time (Days)</label>
                                <input type="number" name="delivery_time" class="form-control" min="1" value="1" required>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="fw-bold">Price ($)</label>
                            <input type="number" name="price" class="form-control" placeholder="50.00" min="5" required>
                        </div>
                        <div class="mb-4">
                            <label class="fw-bold">Description</label>
                            <textarea name="description" class="form-control" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-success w-100 py-3">Publish Gig</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>