<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if (!isset($_GET['id'])) { header("Location: my_orders.php"); exit(); }
$order_id = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch order info to confirm it exists
$order_res = $conn->query("SELECT o.*, s.title FROM orders o JOIN services s ON o.service_id = s.service_id WHERE o.order_id = '$order_id'");
$order = $order_res->fetch_assoc();

include 'navbar.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <h2 class="fw-bold text-dark">Public Feedback</h2>
                <p class="text-muted mb-4">Rate your experience for: <br><strong><?php echo htmlspecialchars($order['title']); ?></strong></p>
                
                <form action="save_review.php" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Select Rating</label>
                        <select name="rating" class="form-select rounded-pill text-center border-success" required>
                            <option value="5">⭐⭐⭐⭐⭐ (5 - Excellent)</option>
                            <option value="4">⭐⭐⭐⭐ (4 - Very Good)</option>
                            <option value="3">⭐⭐⭐ (3 - Good)</option>
                            <option value="2">⭐⭐ (2 - Poor)</option>
                            <option value="1">⭐ (1 - Very Poor)</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Your Review</label>
                        <textarea name="review_text" class="form-control rounded-4" rows="4" placeholder="How was the quality of work?" required></textarea>
                    </div>

                    <button type="submit" class="btn btn-success w-100 rounded-pill fw-bold py-2 shadow-sm">
                        Submit Feedback
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>