<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';
include 'navbar.php';

// Fetching Service ID from URL
$service_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/** * Join with users to get seller information
 */
$sql = "SELECT s.*, u.full_name as seller_name, u.description as seller_bio 
        FROM services s 
        JOIN users u ON s.user_id = u.user_id 
        WHERE s.service_id = '$service_id'";

$res = $conn->query($sql);

if(!$res || $res->num_rows == 0) {
    echo "<div class='container mt-5 pt-5 text-center'>
            <div class='card p-5 border-0 shadow-sm rounded-4'>
                <h4 class='text-muted'>Service not found!</h4>
                <a href='index.php' class='btn btn-success rounded-pill px-4 mt-3'>Back to Home</a>
            </div>
          </div>";
    exit();
}

$gig = $res->fetch_assoc();
$seller_id = $gig['user_id'];
?>

<style>
    body { background-color: #f8f9fa; padding-top: 110px; }
    .main-card { background: white; border-radius: 20px; border: none; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .gig-image { width: 100%; height: 400px; object-fit: cover; }
    .seller-avatar { width: 60px; height: 60px; border-radius: 50%; border: 2px solid #1dbf73; }
    .sticky-sidebar { position: sticky; top: 110px; }
    .price-box { background: white; border-radius: 20px; border: 1px solid #ebebeb; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
    .btn-contact { border: 1px solid #1dbf73; color: #1dbf73; font-weight: 600; transition: 0.3s; }
    .btn-contact:hover { background: #1dbf73; color: white; }
</style>

<div class="container pb-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="main-card mb-4">
                <img src="uploads/<?php echo $gig['image']; ?>" class="gig-image" onerror="this.src='https://placehold.co/800x450?text=Service+Image'">
                <div class="p-4 p-md-5">
                    <h2 class="fw-bold mb-4"><?php echo htmlspecialchars($gig['title']); ?></h2>
                    
                    <div class="d-flex align-items-center mb-4 pb-3 border-bottom">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($gig['seller_name']); ?>&background=1dbf73&color=fff" class="seller-avatar me-3">
                        <div>
                            <h6 class="m-0 fw-bold"><?php echo htmlspecialchars($gig['seller_name']); ?></h6>
                            <div class="text-warning small mt-1">
                                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                                <span class="text-muted ms-1">5.0 (Excellent)</span>
                            </div>
                        </div>
                    </div>

                    <h5 class="fw-bold mb-3 text-uppercase small text-success">About This Gig</h5>
                    <div class="text-muted" style="line-height: 1.8; font-size: 1rem; white-space: pre-line;">
                        <?php echo htmlspecialchars($gig['description']); ?>
                    </div>
                </div>
            </div>

            <div class="main-card p-4 p-md-5">
                <h5 class="fw-bold mb-4">About The Seller</h5>
                <div class="d-flex align-items-center">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($gig['seller_name']); ?>&background=random" class="rounded-circle me-4 shadow-sm" width="80">
                    <div>
                        <h6 class="fw-bold mb-1 fs-5"><?php echo htmlspecialchars($gig['seller_name']); ?></h6>
                        <p class="text-muted mb-0">
                            <?php echo nl2br(htmlspecialchars($gig['seller_bio'] ?? 'Dedicated professional freelancer.')); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="sticky-sidebar">
                <div class="price-box">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="text-muted fw-bold">BASIC PLAN</span>
                        <h2 class="fw-bold text-success m-0">$<?php echo number_format($gig['price'], 2); ?></h2>
                    </div>
                    
                    <div class="mb-4">
                        <ul class="list-unstyled small text-muted">
                            <li class="mb-2"><i class="bi bi-check2 text-success me-2"></i> Quality Service Guarantee</li>
                            <li class="mb-2"><i class="bi bi-check2 text-success me-2"></i> Fast Delivery (3-5 Days)</li>
                            <li class="mb-2"><i class="bi bi-check2 text-success me-2"></i> 24/7 Professional Support</li>
                        </ul>
                    </div>

                    <a href="place_order.php?service_id=<?php echo $service_id; ?>" class="btn btn-dark w-100 rounded-pill py-3 fw-bold shadow-sm mb-3 text-decoration-none text-center d-block">
                        Continue to Order
                    </a>

                    <a href="messages.php?receiver_id=<?php echo $seller_id; ?>" class="btn btn-contact w-100 rounded-pill py-2 text-center d-block text-decoration-none">
                        Contact Seller
                    </a>

                    <p class="text-center text-muted mt-3 mb-0" style="font-size: 0.75rem;">
                        <i class="bi bi-shield-lock-fill me-1"></i> 100% Secure Transaction
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>