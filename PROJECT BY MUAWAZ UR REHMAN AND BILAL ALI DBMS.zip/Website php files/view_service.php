<?php
// view_service.php
session_start();
require 'db.php';
if (!isset($_GET['id'])) { echo "Invalid."; exit; }
$id = intval($_GET['id']);
$stmt = $mysqli->prepare("SELECT s.*, u.full_name, u.user_id AS owner_id FROM services s JOIN users u ON s.user_id = u.user_id WHERE s.service_id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows == 0) { echo "Service not found."; exit; }
$service = $res->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id']) && $_SESSION['role']=='client') {
    $client_id = $_SESSION['user_id'];
    $freelancer_id = $service['owner_id'];
    $total = $service['price'];
    $stmt2 = $mysqli->prepare("INSERT INTO orders (client_id, freelancer_id, service_id, total_amount, status) VALUES (?, ?, ?, ?, 'Pending')");
    $stmt2->bind_param('iiid', $client_id, $freelancer_id, $id, $total);
    if ($stmt2->execute()) {
        header("Location: view_orders.php");
        exit;
    } else $msg = "Order failed.";
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title><?php echo htmlspecialchars($service['title']); ?></title><link rel="stylesheet" href="style.css"></head><body>
<h2><?php echo htmlspecialchars($service['title']); ?></h2>
<p>By: <?php echo htmlspecialchars($service['full_name']); ?></p>
<p><?php echo nl2br(htmlspecialchars($service['description'])); ?></p>
<p>Price: $<?php echo number_format($service['price'],2); ?> • Delivery: <?php echo intval($service['delivery_time']); ?> days</p>

<?php if(isset($msg)) echo "<p class='error'>".htmlspecialchars($msg)."</p>"; ?>

<?php if(isset($_SESSION['user_id']) && $_SESSION['role']=='client'): ?>
  <form method="post">
    <button type="submit">Place Order</button>
  </form>
<?php else: ?>
  <p><a href="login.php">Login as client to place order</a></p>
<?php endif; ?>

</body></html>
