<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['service_id'])) {
    $service_id = mysqli_real_escape_string($conn, $_POST['service_id']);
    $requirements = mysqli_real_escape_string($conn, $_POST['requirements']);
    $client_id = $_SESSION['user_id'];

    // Get price and freelancer_id
    $service = $conn->query("SELECT user_id, price FROM services WHERE service_id = '$service_id'")->fetch_assoc();
    $freelancer_id = $service['user_id'];
    $price = $service['price'];

    // Insert into orders using total_amount
    $sql = "INSERT INTO orders (client_id, freelancer_id, service_id, total_amount, status, requirements, created_at) 
            VALUES ('$client_id', '$freelancer_id', '$service_id', '$price', 'pending', '$requirements', NOW())";

    if ($conn->query($sql)) {
        header("Location: order_details.php?id=" . $conn->insert_id);
    } else {
        die("Error: " . $conn->error);
    }
}
?>